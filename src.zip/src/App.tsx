import React from "react";
import Menu from "./componentes/Menu";
import Tablero from "./componentes/Tablero";
import Modal from "./componentes/Modal";
import "./App.css";

const App: React.FC = () => (
  <div style={{ display: 'flex', maxWidth: '1000px', margin: '0 auto', height: '100vh', alignItems: 'center' }}>
    <Menu />
    <Tablero />
    <Modal />
  </div>
);
export default App;