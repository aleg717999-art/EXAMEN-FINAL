import React, { useState } from 'react';
import { useTienda } from '../store/tienda';
import Lista from './Lista';

const Tablero: React.FC = () => {
  const { agregar, listaActiva } = useTienda();
  const [titulo, setTitulo] = useState("");

  const handleTecla = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && titulo.trim()) { agregar(titulo, listaActiva); setTitulo(""); }
  };

  return (
    <div style={{ flex: 1, padding: '20px' }}>
      {listaActiva !== 'favs' && (
        <input className="input-field" placeholder="Nueva tarea + Enter" value={titulo}
          onChange={(e) => setTitulo(e.target.value)} onKeyDown={handleTecla}
          style={{ width: '100%', marginBottom: '20px' }} />
      )}
      <Lista />
    </div>
  );
};
export default Tablero;