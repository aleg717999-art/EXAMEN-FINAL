import React from 'react';
import { useTienda } from '../store/tienda';

const Menu: React.FC = () => {
  const { listas, listaActiva, setLista } = useTienda();
  const estilo = (id: string) => ({
    padding: '10px', cursor: 'pointer', borderRadius: '10px', marginTop: '5px',
    background: listaActiva === id ? 'var(--tulip-peach)' : 'transparent',
    color: listaActiva === id ? '#1A1A24' : 'var(--text-light)'
  });

  return (
    <aside style={{ width: '250px', background: 'rgba(38,38,53,0.8)', padding: '20px' }}>
      <h2 style={{ color: 'var(--tulip-pink)' }}>Mi Espacio</h2>
      <div onClick={() => setLista('favs')} style={estilo('favs')}>⭐ Destacadas</div>
      <h3 style={{ color: 'var(--text-muted)', marginTop: '20px' }}>MIS LISTAS</h3>
      {listas.map(l => (
        <div key={l.id} onClick={() => setLista(l.id)} style={estilo(l.id)}>
          {l.nombre}
        </div>
      ))}
    </aside>
  );
};
export default Menu;