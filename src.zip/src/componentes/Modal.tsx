import React from 'react';
import { useTienda } from '../store/tienda';

const Modal: React.FC = () => {
  const { tareaActiva, tareas, setTarea, actualizar } = useTienda();
  const t = tareas.find(x => x.id === tareaActiva);
  
  if (!t) return null;
  const estilo = { background: 'rgba(0,0,0,0.2)', color: 'var(--text-light)', padding: '10px', width: '100%', border: 'none' };

  return (
    <div style={{ position: 'fixed', right: 0, top: 0, height: '100vh', width: '350px', background: 'var(--surface-dark)', padding: '20px', zIndex: 1000 }}>
      <button onClick={() => setTarea(null)} style={{ float: 'right', background: 'none', border: 'none', color: 'white', cursor: 'pointer' }}>✕</button>
      <input value={t.titulo} onChange={(e) => actualizar(t.id, { titulo: e.target.value })}
        style={{ ...estilo, fontSize: '20px', background: 'transparent' }} />
      <label style={{ color: 'var(--tulip-pink)', fontSize: '12px' }}>VENCIMIENTO</label>
      <input type="date" value={t.vencimiento || ''} onChange={(e) => actualizar(t.id, { vencimiento: e.target.value })} style={estilo} />
      <label style={{ color: 'var(--tulip-pink)', fontSize: '12px', marginTop: 15, display: 'block' }}>DETALLES</label>
      <textarea value={t.detalles} onChange={(e) => actualizar(t.id, { detalles: e.target.value })} style={{ ...estilo, height: '150px' }} />
    </div>
  );
};
export default Modal;