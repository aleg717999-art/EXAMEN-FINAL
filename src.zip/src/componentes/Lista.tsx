import React from 'react';
import { useTienda } from '../store/tienda';
import Tarea from './Tarea';

const Lista: React.FC = () => {
  const { tareas, listaActiva } = useTienda();
  const p = tareas.filter(t => (listaActiva === 'favs' ? t.destacada : t.idLista === listaActiva) && !t.completada);
  const c = tareas.filter(t => (listaActiva === 'favs' ? t.destacada : t.idLista === listaActiva) && t.completada);
  
  return (
    <>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {p.map((t) => <Tarea key={t.id} tarea={t} />)}
      </ul>
      {c.length > 0 && (
        <details style={{ marginTop: '30px' }}>
          <summary style={{ cursor: 'pointer', color: 'var(--text-muted)' }}>Completadas</summary>
          <ul style={{ listStyle: 'none', padding: 0, opacity: 0.6 }}>
            {c.map(t => <li key={t.id} style={{ margin: '10px 0' }}>{t.titulo}</li>)}
          </ul>
        </details>
      )}
    </>
  );
};
export default Lista;