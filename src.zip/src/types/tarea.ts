export interface Lista { id: string; nombre: string; }
export interface Tarea {
  id: string; idLista: string; idPadre: string | null;
  titulo: string; detalles: string; vencimiento: string | null;
  destacada: boolean; completada: boolean; posicion: number;
}
export interface EstadoTareas {
  listas: Lista[]; tareas: Tarea[]; listaActiva: string; tareaActiva: string | null;
  setLista: (id: string) => void; setTarea: (id: string | null) => void;
  agregar: (t: string, l: string) => void; 
  actualizar: (id: string, u: Partial<Tarea>) => void;
  alternar: (id: string, campo: 'completada'|'destacada') => void;
  reordenar: (inicio: number, fin: number) => void;
}