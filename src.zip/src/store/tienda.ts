import { create } from 'zustand';
import type { EstadoTareas, Tarea } from '../types/tarea';

export const useTienda = create<EstadoTareas>((set) => ({
  listas: [{ id: "l1", nombre: "Universidad" }, { id: "l2", nombre: "Personal" }],
  tareas: [], listaActiva: "l1", tareaActiva: null,
  setLista: (id) => set({ listaActiva: id, tareaActiva: null }),
  setTarea: (id) => set({ tareaActiva: id }),
  agregar: (titulo, idLista) => set((s) => {
    const pos = s.tareas.length ? Math.max(...s.tareas.map(t => t.posicion)) + 1000 : 1000;
    const nueva: Tarea = { id: crypto.randomUUID(), idLista, idPadre: null, titulo, detalles: "", vencimiento: null, destacada: false, completada: false, posicion: pos };
    return { tareas: [...s.tareas, nueva] };
  }),
  actualizar: (id, u) => set((s) => ({ tareas: s.tareas.map(t => t.id === id ? { ...t, ...u } : t) })),
  alternar: (id, c) => set((s) => ({ tareas: s.tareas.map(t => t.id === id ? { ...t, [c]: !t[c] } : t) })),
  reordenar: (inicio, fin) => set((s) => {
    const lista = s.tareas.filter(t => t.idLista === s.listaActiva && !t.completada).sort((a,b) => a.posicion - b.posicion);
    const [movida] = lista.splice(inicio, 1); lista.splice(fin, 0, movida);
    const act = lista.map((t, i) => ({ ...t, posicion: (i + 1) * 1000 }));
    return { tareas: s.tareas.map(t => act.find(u => u.id === t.id) || t) };
  })
}));